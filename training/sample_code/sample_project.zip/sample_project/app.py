"""
<TO_EDIT>
========================
"""

__author__ = "Danh Doan"
__email__ = "danhdoancv@gmail.com"
__date__ = "2021/08/20"
__status__ = "development"


# =============================================================================


import logging

from libs.cli import cli_parser

logging.basicConfig(
    level=logging.DEBUG, format="%(asctime)s %(threadName)s [%(levelname)s] %(message)s"
)


# =============================================================================


def main():
    """Main application"""

    _args = cli_parser.get_args()


# =============================================================================


if __name__ == "__main__":
    logging.info("Experiment: <TO_EDIT>\n")

    main()

    logging.info("Process Done")


# =============================================================================
