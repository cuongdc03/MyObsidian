"""
Utilities for Image
===================
"""

# =============================================================================


def dummy_func(x):
    """Double an input number

    Args:
        x (int) : input number

    Returns:
        (int) : double of the input
    """

    return x * 2


# =============================================================================
