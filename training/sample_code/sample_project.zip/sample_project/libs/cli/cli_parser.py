"""
CLI Parser
==========

Parse CLI arguments
"""

__author__ = "Danh Doan"
__email__ = "danhdoancv@gmail.com"
__date__ = "2021/08/20"
__status__ = "development"


# =============================================================================


import argparse


# =============================================================================


def get_args():
    """Parse CLI arguments from user

    Returns:
        (object) : parsed CLI arguments
    """

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--output", "-o", type=str, default="./output", help="Path to output directory"
    )

    return parser.parse_args()


# =============================================================================
