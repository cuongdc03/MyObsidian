#!/bin/bash


VENV_NAME=.venv
PYTHON_PATH=`which python3`
REQUIREMENT_FILE=requirements.txt

if [ ! -d ${VENV_NAME} ] 
then
	echo "Virtual environment is being set up..."

	sudo apt update && sudo apt install -yqq virtualenv

	virtualenv ${VENV_NAME} -p ${PYTHON_PATH}
	source ${VENV_NAME}/bin/activate
	pip3 install -r ${REQUIREMENT_FILE}

	echo "Virtual environment setup done - Name:" ${VENV_NAME}
else
	source ${VENV_NAME}/bin/activate
fi

echo "Virtual environment is activated"
