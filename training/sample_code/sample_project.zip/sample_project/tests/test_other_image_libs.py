import random
from image_processing import other_libs


# =============================================================================


def test_dummy_func():
    num_tests = 10
    lower_bound, upper_bound = 0, 1000
    testcases = [random.randint(lower_bound, upper_bound) for _ in range(num_tests)]

    for testcase in testcases:
        assert other_libs.another_dummpy_func(testcase) == testcase + 10


# =============================================================================


def test_list_append():
    num_tests = 10
    max_list_length = 100
    lower_bound, upper_bound = 0, 1000

    for _ in range(num_tests):
        num_elems = random.randint(1, max_list_length)
        lst = [random.randint(lower_bound, upper_bound) for _ in range(num_elems)]

        old_length = len(lst)

        new_value = random.randint(lower_bound, upper_bound)

        lst.append(new_value)

        assert len(lst) == old_length + 1
        assert lst[-1] == new_value


# =============================================================================
