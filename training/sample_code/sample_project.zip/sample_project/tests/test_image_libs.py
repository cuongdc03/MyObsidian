import random
from image_processing import image_utils


# =============================================================================


def test_dummy_func():
    num_tests = 10
    lower_bound, upper_bound = 0, 1000
    testcases = [random.randint(lower_bound, upper_bound) for _ in range(num_tests)]

    for testcase in testcases:
        assert image_utils.dummy_func(testcase) == 2 * testcase


# =============================================================================
