"""
Accumulator Test Module
=======================

Module to test Accumulator functionality
"""

import random
from libs.accumulator import Accumulator


# =============================================================================

# define Epsilon as a very small value for equality comparision
EPS = 1e-9


# =============================================================================


def test_integer_sequence():
    """Test accumulator module with integer sequence"""

    num_tests = 100
    lower_bound, upper_bound = 0, 10000
    testcases = [random.randint(lower_bound, upper_bound) for _ in range(num_tests)]

    accumulator = Accumulator()
    vals = []
    for testcase in testcases:
        vals.append(testcase)
        curr_mean = sum(vals) / len(vals)
        accumulator.update(testcase)

        acc_mean = accumulator.mean

        assert abs(acc_mean - curr_mean) < EPS


# =============================================================================


def test_float_sequence():
    """Test accumulator module with floating-point sequence"""

    num_tests = 100
    lower_bound, upper_bound = 0, 10000
    testcases = [random.uniform(lower_bound, upper_bound) for _ in range(num_tests)]

    accumulator = Accumulator()
    vals = []
    for testcase in testcases:
        vals.append(testcase)
        curr_mean = sum(vals) / len(vals)
        accumulator.update(testcase)

        acc_mean = accumulator.mean

        assert abs(acc_mean - curr_mean) < EPS


# =============================================================================
