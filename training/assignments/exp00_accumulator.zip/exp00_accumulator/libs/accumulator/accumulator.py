"""
Accumulator class
=================

Module to accumulately mean value of a value sequence
"""

__author__ = 'Danh Doan'
__email__ = 'danhdoan@gmail.com'
__date__ = '2022/10/14'
__status__ = 'release'


# =============================================================================


class Accumulator:
    """Accumulator class"""

    def __init__(self):
        """Initialize Accumulator object"""

        self._total_sum = ...
        self._len = ...

    def update(self, val):
        """Update new value from sequence

        Args:
            val (int, float) : new value to update
        """
        pass


    @property
    def mean(self):
        """Return current mean of the whole sequence

        Returns:
            (float) : current mean value of the sequence
        """

        pass


# =============================================================================
