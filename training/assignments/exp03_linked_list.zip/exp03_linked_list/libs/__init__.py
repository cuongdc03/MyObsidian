"""
Register Linked List related modules
"""


# =============================================================================


from .list_node import ListNode
from .linked_list import LinkedList


# =============================================================================
