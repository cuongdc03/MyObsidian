"""
Linked List
===========

Class implements Linked List feature
"""


# =============================================================================


from libs import ListNode


# =============================================================================


class LinkedList:
    """Linked List class"""

    def __init__(self, vals=None):
        """Intialize Linked List object

        Args:
            vals (List[int] | None) : list of values to initialize

        """
        self._head, self._len = LinkedList._build_from_list(vals)

    @property
    def head(self):
        """Getter for head

        Returns:
            (ListNode) : head of the list
        """

        pass


    @staticmethod
    def _build_from_list(vals):
        """Build a linked list from a given input value list

        Args:
            vals (List[int] | None) : list of values to initialize

        Returns:
            (ListNode) : head of the created linked list
            (int) : length of the linked list
        """

        pass

    def append_left(self, val):
        """Append a new val to the beginning of the linked list

        Args:
            val (int) : new value to append

        Returns:
            (LinkedList) : the list itself
        """

        pass

    @property
    def left_val(self):
        """Getter of the left-most value in the linked list

        Returns:
            (int) : left-most value
        """

        pass

    @property
    def right_val(self):
        """Getter of the right-most value in the linked list

        Returns:
            (int) : right-most value
        """

        pass

    def append_right(self, val):
        """Append a new val to the end of the linked list

        Args:
            val (int) : new value to append

        Returns:
            (LinkedList) : the list itself
        """

        pass

    def __len__(self):
        """Return the current length of the linked list

        Returns:
            (int) : current length of the linked list
        """

        pass

    def pop_left(self):
        """Pop and return value from the beginning

        Returns:
            (int) : top-left value of the linked list
        """

        pass

    def pop_right(self):
        """Pop and return value from the end

        Returns:
            (int) : right-end value of the linked list
        """

        pass

    def to_list(self):
        """Convert values in the linked list to a list

        Returns:
            vals (List[int]) : list containing values in the linked list
        """

        pass

# =============================================================================
