"""
Linked List test module
=======================

Test functionalities of Linked List module
"""


# =============================================================================


import random
import pytest
from libs import ListNode, LinkedList


# =============================================================================


def generate_random_int(lower_bound=0, upper_bound=10000):
    """Generate a random integer value given a range

    Args:
        lower_bound (int) : lower bound of the range
        upper_bound (int) : upper bound of the range

    Returns:
        (int) : generated random value
    """

    return random.randint(lower_bound, upper_bound)


# =============================================================================


def test_linked_list_init_and_length():
    """Test Initialization of Linked List"""

    lst = LinkedList()
    assert len(lst) == 0
    assert lst.head is None

    num_tests = 100
    for _ in range(num_tests):
        num_elements = generate_random_int(lower_bound=1, upper_bound=1000)
        random_vals = [generate_random_int() for _ in range(num_elements)]

        lst = LinkedList(random_vals)
        assert len(lst) == len(random_vals)
        assert lst.head is not None

        lst_vals = lst.to_list()
        assert lst_vals == random_vals
        assert lst_vals is not random_vals


# =============================================================================


def test_linked_list_left_val():
    """Test getter of left-most value in a linked list"""

    lst = LinkedList()
    
    with pytest.raises(ValueError):
        assert lst.left_val

    random_val = generate_random_int()
    lst = LinkedList([random_val])
    assert len(lst) == 1
    assert lst.left_val == random_val


# =============================================================================


def test_linked_list_right_val():
    """Test getter of right-most value in a linked list"""

    lst = LinkedList()
    
    with pytest.raises(ValueError):
        assert lst.right_val

    random_val = generate_random_int()
    lst = LinkedList([random_val])
    assert len(lst) == 1
    assert lst.right_val == random_val


# =============================================================================


def test_linked_list_append_left():
    """Test Left append of Linked List"""

    lst = LinkedList()
    assert len(lst) == 0
    assert lst.head is None

    num_tests = 100
    for i in range(num_tests):
        random_val = generate_random_int()
        output = lst.append_left(random_val)
        assert isinstance(output, LinkedList)
        assert lst.left_val == random_val
        assert len(lst) == i+1


# =============================================================================


def test_linked_list_append_right():
    """Test Right append of Linked List"""

    lst = LinkedList()
    assert len(lst) == 0
    assert lst.head is None

    num_tests = 100
    for i in range(num_tests):
        random_val = generate_random_int()
        output = lst.append_right(random_val)
        assert isinstance(output, LinkedList)
        assert lst.right_val == random_val
        assert len(lst) == i+1


# =============================================================================


def test_linked_list_pop_left():
    """Test Left pop of Linked List"""

    lst = LinkedList()
    assert len(lst) == 0
    with pytest.raises(ValueError):
        lst.pop_left()

    num_tests = 100
    for i in range(num_tests):
        num_elements = generate_random_int(lower_bound=1, upper_bound=100)
        random_vals = [generate_random_int() for _ in range(num_elements)]

        lst = LinkedList(random_vals)
        for i, random_val in enumerate(random_vals):
            assert random_val == lst.pop_left()
            assert len(lst) == len(random_vals) - i - 1

    with pytest.raises(ValueError):
        lst.pop_left()


# =============================================================================


def test_linked_list_pop_right():
    """Test Right pop of Linked List"""

    lst = LinkedList()
    assert len(lst) == 0
    with pytest.raises(ValueError):
        lst.pop_right()

    num_tests = 100
    for i in range(num_tests):
        num_elements = generate_random_int(lower_bound=1, upper_bound=100)
        random_vals = [generate_random_int() for _ in range(num_elements)]

        lst = LinkedList(random_vals)
        for i, random_val in enumerate(reversed(random_vals)):
            assert random_val == lst.pop_right()
            assert len(lst) == len(random_vals) - i - 1

    with pytest.raises(ValueError):
        lst.pop_right()


# =============================================================================


def test_linked_list_cascade():
    """Test Cascade feature of Linked List

    Suppose there a linked list `lst`
    An example of Cascade operations is:
        lst.append_left(1).append_left(2)....
    """

    num_tests = 100
    for i in range(num_tests):
        lst = LinkedList()
        assert len(lst) == 0
        lst_id = id(lst)
        num_elements = generate_random_int(lower_bound=1, upper_bound=100)
        random_vals = [generate_random_int() for _ in range(num_elements)]

        for random_val in random_vals:
            lst = lst.append_left(random_val)
            assert id(lst) == lst_id

        assert lst.to_list() == random_vals[::-1]


# =============================================================================
