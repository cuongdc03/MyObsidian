"""
Parser Test Module
=======================

Module to test Parser functionality
"""

import pytest
import random
from libs.parser import Parser
from libs.factories import HexadecimalFactory, BinaryFactory, Factory


# =============================================================================


def test_hexadecimal_sequence():
    """Test Parser module with hexadecimal sequence"""

    num_tests = 100
    lower_bound, upper_bound = 0, 10000
    testcases = [random.randint(lower_bound, upper_bound) for _ in range(num_tests)]
    hex_testcases = [hex(testcase) for testcase in testcases]

    hex_factory = HexadecimalFactory()
    decimals = Parser.parse(hex_testcases, hex_factory)
    assert decimals == testcases
    assert decimals is not testcases


# =============================================================================

def test_binary_sequence():
    """Test Parser module with binary sequence"""

    num_tests = 100
    lower_bound, upper_bound = 0, 10000
    testcases = [random.randint(lower_bound, upper_bound) for _ in range(num_tests)]
    hex_testcases = [bin(testcase) for testcase in testcases]

    hex_factory = BinaryFactory()
    decimals = Parser.parse(hex_testcases, hex_factory)
    assert decimals == testcases
    assert decimals is not testcases


# =============================================================================


def test_factory_base_class():
    """Test initialization of base factory class"""

    # Abstract base class should not be instantiated
    with pytest.raises(TypeError):
        obj = Factory()


# =============================================================================
