"""
Common Utilities
================

Common Support functions
"""

__author__ = "Danh Doan"
__email__ = "danhdoancv@gmail.com"
__date__ = "2020/04/19"
__status__ = "development"


# =============================================================================


import logging
import inspect
import json

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


# =============================================================================


DEBUG_LENGTH = 79
DEBUG_SEPERATOR = "="


# =============================================================================


def dbg(*args):
    """Debug by print values

    Arguments:
        args (obj) : packed list of values to debug
    """

    caller = inspect.stack()[1]
    caller_module = inspect.getmodule(caller[0]).__name__
    caller_function, caller_line_number = caller.function, caller.lineno
    dbg_prefix = f"[{caller_module}-{caller_function}:{caller_line_number}]"
    logging.debug(dbg_prefix.ljust(DEBUG_LENGTH, DEBUG_SEPERATOR))

    for arg in args:
        if isinstance(arg, list):
            print_list(arg)
        else:
            logging.debug(arg)

    logging.debug("")


def print_list(lst):
    """Print items of a list

    Arguments:
        lst (List[obj]) : list of object to print
    """

    for i, item in enumerate(lst):
        logging.debug("%d %s", i + 1, item)


# =============================================================================


def load_json(json_path, encoding="utf-8"):
    """Load data from JSON file

    Args:
        json_path (str) : path to input JSON file

    Returns:
        (obj) : data loaded from JSON file
    """
    dbg(json_path)

    data = None
    with open(json_path, "r", encoding=encoding) as inp_file:
        data = json.load(inp_file)

    return data


# =============================================================================
