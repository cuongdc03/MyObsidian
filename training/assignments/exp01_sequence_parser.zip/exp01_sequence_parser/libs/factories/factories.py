"""
Parser factories
================

Factories for Hexadecimal and Binary Parser
"""

from abc import ABC, abstractmethod


# =============================================================================


# define Abstract base class
# it should not be modified
class Factory(ABC):
    @abstractmethod
    def parse_number(self, val):
        pass


# =============================================================================


class HexadecimalFactory(Factory):
    """Hexadecimal parser class"""

    def parse_number(self, val):
        """Parse hexadecimal value to decimal value

        Args:
            val (str) : hexadecimal value to parse

        Returns:
            (int) : result in decimal
        """

        return ...


# =============================================================================


class BinaryFactory(Factory):
    """Binary parser class"""

    def parse_number(self, val):
        """Parse binary value to decimal value

        Args:
            val (str) : binary value to parse

        Returns:
            (int) : result in decimal
        """

        return ...


# =============================================================================
