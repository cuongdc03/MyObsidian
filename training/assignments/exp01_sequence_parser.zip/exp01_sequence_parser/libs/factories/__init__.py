"""
Register Parser Factory modules
"""


# =============================================================================


from .factories import HexadecimalFactory, BinaryFactory, Factory


# =============================================================================
