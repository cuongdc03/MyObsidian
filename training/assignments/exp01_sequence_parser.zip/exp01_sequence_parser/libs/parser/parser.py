"""
Parser class
============
"""


# =============================================================================


class Parser:
    """Parser class"""

    @staticmethod
    def parse(sequence, factory):
        """Given a sequence and corresponding factory 
        parse the input sequence to decimal sequence

        Args:
            sequence (List[str]) : list of hexadecimal/binary values
            factory (Factory) : factory for parsing task

        Returns:
            output (List[int]) : list of parsed decimal values
        """

        output = []

        # parse each element in sequence by using `factory` object's method
        # and append to `output

        return output


# =============================================================================
