"""
List Node Test Module
=====================

Module to test List Node functionality
"""

import random
import pytest
from libs import ListNode


# =============================================================================


def generate_random_int(lower_bound=0, upper_bound=10000):
    """Generate a random integer value given a range

    Args:
        lower_bound (int) : lower bound of the range
        upper_bound (int) : upper bound of the range

    Returns:
        (int) : generated random value
    """

    return random.randint(lower_bound, upper_bound)


# =============================================================================


def test_default_list_node():
    """Test default List node usage"""

    node = ListNode()

    assert node.val == 0
    assert node.next is None

    random_val = generate_random_int()
    node.val = random_val


# =============================================================================


def test_list_node():
    """Test List node usage"""

    random_val = generate_random_int()
    node = ListNode(random_val)

    assert node.val == random_val
    assert node.next is None

    another_node = ListNode(generate_random_int())
    assert another_node.next is None

    another_node.next = node
    assert another_node.next is not None
    assert another_node.next.val is random_val
    assert another_node.next.next is None
    assert another_node.next is node


# =============================================================================


def test_value_assignment():
    """Test assignment of value of a List node"""

    node = ListNode()
    random_val = generate_random_int()

    node.val = random_val

    assert node.val == random_val
    assert node.next is None

    with pytest.raises(ValueError):
        node.val = "dummy value"

    with pytest.raises(ValueError):
        node.val = -float("inf")


# =============================================================================


def test_next_node_assignment():
    """Test assignment of next node of a List node"""

    random_val = generate_random_int()
    node = ListNode(random_val)

    assert node.val == random_val
    assert node.next is None

    with pytest.raises(ValueError):
        node.next = "dummy value"

    with pytest.raises(ValueError):
        node.next = generate_random_int()


# =============================================================================
