"""
List Node
=========

Class representing a linked list node
"""


# =============================================================================


class ListNode:
    """List Node class"""

    def __init__(self, val=0, next_node=None):
        """Initialize a new node with given value and next node

        Args:
            val (int) : value for creation
            next_node (ListNode) : next node
        """

        self._val = ...
        self._next = ...

    @property
    def val(self):
        """Return value of a node

        Returns:
            (int) : node's value
        """

        pass

    @val.setter
    def val(self, new_val):
        """Set new value for a node

        Args:
            new_val (obj) : new value to set
        """

        pass

    @property
    def next(self):
        """Return next node of a node

        Returns:
            (ListNode) : node's next node
        """

        pass

    @next.setter
    def next(self, node):
        """Set a new next node for a node

        Args:
            node (ListNode) : new next node to set
        """

        pass

# =============================================================================
